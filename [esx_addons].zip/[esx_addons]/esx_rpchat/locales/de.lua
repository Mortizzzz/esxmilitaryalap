Locales['de'] = {
  ['ooc_prefix'] = 'OOC | %s',
  ['twt_help'] = 'Tweet Senden',
  ['twt_prefix'] = '^0[^4Twitter^0] (^5@%s^0)',
  ['me_help'] = 'Persönliche Aktionen',
  ['me_prefix'] = 'Ich | %s',
  ['do_help'] = 'RP Information',
  ['do_prefix'] = 'Machen | %s',
  ['generic_argument_name'] = 'Nachricht',
  ['generic_argument_help'] = 'Die Nachricht',
}
