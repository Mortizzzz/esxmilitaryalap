Locales['fi'] = {
  ['ooc_prefix'] = 'OOC | %s',
  ['twt_help'] = 'lähetä twiitti',
  ['twt_prefix'] = '^0[^4Twitter^0] (^5@%s^0)',
  ['me_help'] = 'tee jotain',
  ['me_prefix'] = 'me | %s',
  ['do_help'] = 'tee jotain',
  ['do_prefix'] = 'do | %s',
  ['generic_argument_name'] = 'viesti',
  ['generic_argument_help'] = 'viestin sisältö',
}
