Locales['hu'] = {
  ['ooc_prefix'] = 'OOC | %s',
  ['twt_help'] = 'tweet küldése',
  ['twt_prefix'] = '^0[^4Twitter^0] (^5@%s^0)',
  ['me_help'] = 'személyes cselekvés',
  ['me_prefix'] = 'me | %s',
  ['do_help'] = 'RP információ',
  ['do_prefix'] = 'do | %s',
  ['generic_argument_name'] = 'üzenet',
  ['generic_argument_help'] = 'az üzenet',
}
