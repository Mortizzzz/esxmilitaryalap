Locales['it'] = {
  ['ooc_prefix'] = 'OOC | %s',
  ['twt_help'] = 'Invia tweet',
  ['twt_prefix'] = '^0[^4Twitter^0] (^5@%s^0)',
  ['me_help'] = 'Azione Personale',
  ['me_prefix'] = 'me | %s',
  ['do_help'] = 'Azione RP',
  ['do_prefix'] = 'fa | %s',
  ['generic_argument_name'] = 'Messaggio',
  ['generic_argument_help'] = 'il messaggio',
}
