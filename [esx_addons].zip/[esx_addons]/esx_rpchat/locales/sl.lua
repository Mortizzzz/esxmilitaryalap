Locales['sl'] = {
  ['ooc_prefix'] = 'OOC | %s',
  ['twt_help'] = 'poslji twita',
  ['twt_prefix'] = '^0[^4Twitter^0] (^5@%s^0)',
  ['me_help'] = 'osebne stvari',
  ['me_prefix'] = 'jaz | %s',
  ['do_help'] = 'RP informacija',
  ['do_prefix'] = 'naredi | %s',
  ['generic_argument_name'] = 'sporocilo',
  ['generic_argument_help'] = 'sporocilo',
}
