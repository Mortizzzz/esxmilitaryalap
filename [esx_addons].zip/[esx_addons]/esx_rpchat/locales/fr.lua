Locales['fr'] = {
  ['ooc_prefix'] = 'hrp | %s',
  ['twt_help'] = 'envoie un tweet',
  ['twt_prefix'] = '^0[^4Twitter^0] (^5@%s^0)',
  ['me_help'] = 'action personnelle',
  ['me_prefix'] = 'me | %s',
  ['do_help'] = 'RP information',
  ['do_prefix'] = 'faire | %s',
  ['generic_argument_name'] = 'message',
  ['generic_argument_help'] = 'le message',
}
