Locales['el'] = {
    ['ooc_prefix'] = 'Εκτός ρόλου | %s',
    ['twt_help'] = 'Αποστολή tweet',
    ['twt_prefix'] = '^0[^4Twitter^0] (^5@%s^0)',
    ['me_help'] = 'Προσωπική ενέργεια',
    ['me_prefix'] = 'Εγώ | %s',
    ['do_help'] = 'Πληροφορίες RP',
    ['do_prefix'] = 'Κάνω | %s',
    ['generic_argument_name'] = 'Μήνυμα',
    ['generic_argument_help'] = 'Το μήνυμα',
}
