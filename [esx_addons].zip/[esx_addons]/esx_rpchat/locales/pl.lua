Locales['pl'] = {
  ['ooc_prefix'] = 'OOC | %s',
  ['twt_help'] = 'wyślij tweeta',
  ['twt_prefix'] = '^0[^4Twitter^0] (^5@%s^0)',
  ['me_help'] = 'opisz akcję',
  ['me_prefix'] = 'me | %s',
  ['do_help'] = 'opisz sytuację',
  ['do_prefix'] = 'do | %s',
  ['generic_argument_name'] = 'wiadomość',
  ['generic_argument_help'] = 'wysyłana wiadomość',
}
