Locales['sr'] = {
  ['ooc_prefix'] = 'OOC | %s',
  ['twt_help'] = 'pošalji tweet',
  ['twt_prefix'] = '^0[^4Twitter^0] (^5@%s^0)',
  ['me_help'] = 'personalne akcije',
  ['me_prefix'] = 'me | %s',
  ['do_help'] = 'RP informacije',
  ['do_prefix'] = 'do | %s',
  ['generic_argument_name'] = 'poruka',
  ['generic_argument_help'] = 'poruka',
}
