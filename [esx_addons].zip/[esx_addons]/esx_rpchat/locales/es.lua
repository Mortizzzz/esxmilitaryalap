Locales['es'] = {
  ['ooc_prefix'] = 'OOC | %s',
  ['twt_help'] = 'Mandar tweet',
  ['twtanon_help'] = 'Mandar tweet anonimo',
  ['twt_prefix'] = '^0[^4Twitter^0] (^5@%s^0)',
  ['me_help'] = 'Accion Global',
  ['me_prefix'] = 'me | %s',
  ['do_help'] = 'Accion Personal',
  ['do_prefix'] = 'do | %s',
  ['generic_argument_name'] = 'mensaje',
  ['generic_argument_help'] = 'el mensaje',
}
