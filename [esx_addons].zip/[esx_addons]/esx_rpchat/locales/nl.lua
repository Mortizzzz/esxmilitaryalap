Locales['nl'] = {
  ['ooc_prefix'] = 'OOC | %s',
  ['twt_help'] = 'stuur tweet',
  ['twt_prefix'] = '^0[^4Twitter^0] (^5@%s^0)',
  ['me_help'] = 'persoonlijke actie',
  ['me_prefix'] = 'ik | %s',
  ['do_help'] = 'RP informatie',
  ['do_prefix'] = 'doe | %s',
  ['generic_argument_name'] = 'bericht',
  ['generic_argument_help'] = 'het bericht',
}
