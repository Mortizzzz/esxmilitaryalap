Config = {}

Config.Locale = GetConvar('esx:locale', 'en')
Config.OnlyFirstname = false
Config.EnableESXIdentity = true -- RP names
