INSERT INTO `items` (`name`, `label`, `weight`) VALUES
	('bread', 'Brood', 1),
	('water', 'Water', 1)
;