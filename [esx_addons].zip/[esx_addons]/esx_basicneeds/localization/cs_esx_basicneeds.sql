INSERT INTO `items` (`name`, `label`, `weight`) VALUES
	('bread', 'Chleba', 1),
	('water', 'Voda', 1)
;
