Locales['it'] = {
  ['used_bread'] = 'hai usato 1x panino',
  ['used_water'] = 'hai usato 1x acqua',
  ['got_healed'] = 'Sei stato curato.'
}
