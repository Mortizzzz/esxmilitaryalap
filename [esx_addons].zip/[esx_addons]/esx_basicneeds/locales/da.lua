Locales['da'] = {
  ['used_food'] = 'Du har spist 1x %s',
  ['used_drink'] = 'Du har drukket 1x %s',
  ['got_healed'] = 'Du er blevet helbredt.'
}
