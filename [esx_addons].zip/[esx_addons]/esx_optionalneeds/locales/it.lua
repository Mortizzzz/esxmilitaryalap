Locales['it'] = {
	
	['used_beer'] = 'Hai usato 1x Birra',

}
