Locales['he'] = {
	['used_beer'] = 'השתמשתם בבירה אחת',
}
