Locales['es'] = {
    
    ['used_beer'] = 'Has usado 1x Cerveza',

}
