Locales['da'] = {
	
	['used_beer'] = 'du brugte 1x Øl',

}