Locales['nl'] = {
	
	['used_beer'] = 'Je hebt een biertje gedronken.',

}
