Locales['sl'] = {
	['used_beer'] = 'Vi ste popili Laški pir 1x.',
}
