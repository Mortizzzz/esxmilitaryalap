Locales['sr'] = {
	
	['used_beer'] = 'Iskoristili ste 1x Pivo',

}
