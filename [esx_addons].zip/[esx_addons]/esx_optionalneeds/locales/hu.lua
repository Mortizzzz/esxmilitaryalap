Locales['hu'] = {
	['used_beer'] = 'Ittál egy Sört',
}