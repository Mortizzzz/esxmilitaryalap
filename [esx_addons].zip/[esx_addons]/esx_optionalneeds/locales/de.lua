Locales['de'] = {
	['used_beer'] = 'Du trinkst 1x Bier',
}
