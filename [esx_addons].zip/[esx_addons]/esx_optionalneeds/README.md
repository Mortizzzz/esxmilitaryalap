<h1 align='center'>[ESX] Optional Needs</a></h1><p align='center'><b><a href='https://discord.esx-framework.org/'>Discord</a> - <a href='https://documentation.esx-framework.org/legacy/installation'>Documentation</a></b></h5>
ESX Optional Needs

[REQUIREMENTS]
- esx_status https://github.com/esx-framework/esx_status

[INSTALLATION]

1) CD in your resources folder
2) Clone the repository
```
git clone https://github.com/esx-framework/esx_optionalneeds [esx]/esx_optionalneeds
```
3) Add this in your server.cfg :

```
start esx_optionalneeds
```
