Locales['hu'] = {
  ['activated']   = 'Bekapcsolva',
  ['deactivated'] = 'Kikapcsolva',
  ['increaseSpeed'] = 'Sebbeség növelése',
  ['decreaseSpeed'] = 'Sebbeség csökkenentése',
  ['cruiseControl'] = 'Tempomat',

  --Seatbelt
  ['toggleSeatbelt'] = "Toggle Seatbelt",
  ["seatbeltOn"] = "Seatbelt ON",
  ["seatbeltOff"] = "Seatbelt OFF"
}
