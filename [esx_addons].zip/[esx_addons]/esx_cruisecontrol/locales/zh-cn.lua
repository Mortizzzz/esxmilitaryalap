Locales['zh-cn'] = {
  ['activated']   = '车辆限速巡航已开启!',
  ['deactivated'] = '车辆限速巡航已关闭',
  ['increaseSpeed'] = '已增加巡航最高限速',
  ['decreaseSpeed'] = '已减少巡航最高限速',
  ['cruiseControl'] = '巡航控制',

  --Seatbelt
  ['toggleSeatbelt'] = "Toggle Seatbelt",
  ["seatbeltOn"] = "Seatbelt ON",
  ["seatbeltOff"] = "Seatbelt OFF"
}
