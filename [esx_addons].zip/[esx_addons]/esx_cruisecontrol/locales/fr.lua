Locales['fr'] = {
  ['activated']   = 'Activé',
  ['deactivated'] = 'Désactivé',
  ['increaseSpeed'] = 'Augmenter la vitesse',
  ['decreaseSpeed'] = 'Diminuer la vitesse',
  ['cruiseControl'] = 'Régulateur de vitesse',

  --Seatbelt
  ['toggleSeatbelt'] = "Mettre/enlever la ceinture de sécurité",
  ["seatbeltOn"] = "Ceinture de sécurité mise",
  ["seatbeltOff"] = "Ceinture de sécurité enlevée"
}
