Locales['sv'] = {
    ['activated']   = 'Farthållare aktiverad',
    ['deactivated'] = 'Farthållare avaktiverad',
    ['increaseSpeed'] = 'Höj fart',
    ['decreaseSpeed'] = 'Sänk fart',
    ['cruiseControl'] = 'Farthållare',
  
    --Seatbelt
    ['toggleSeatbelt'] = "Aktivera bälte",
    ["seatbeltOn"] = "Säkerhetsbälte PÅ",
    ["seatbeltOff"] = "Säkerhetsbälte AV"
  }
