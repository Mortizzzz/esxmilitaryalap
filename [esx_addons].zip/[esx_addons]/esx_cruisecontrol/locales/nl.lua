Locales['nl'] = {
  ['activated']   = 'geactiveerd',
  ['deactivated'] = 'gedeactiveerd',
  ['increaseSpeed'] = 'Verhoog snelheid',
  ['decreaseSpeed'] = 'Verlaag snelheid',
  ['cruiseControl'] = 'Snelheidsregelaar',

  --Seatbelt
  ['toggleSeatbelt'] = "Doe gordel aan / uit",
  ["seatbeltOn"] = "Gordel aan",
  ["seatbeltOff"] = "Gordel uit"
}
