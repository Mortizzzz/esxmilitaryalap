Locales['de'] = { 
  ['activated']   = 'Fahrkontrolle aktiviert',
  ['deactivated'] = 'Fahrkontrolle deaktiviert',
  ['increaseSpeed'] = 'Geschwindigkeit erhöhen',
  ['decreaseSpeed'] = 'Geschwindigkeit verniedrigeren',
  ['cruiseControl'] = 'Fahrkontrolle',
  
  --Seatbelt
  ['toggleSeatbelt'] = "Toggle Seatbelt",
  ["seatbeltOn"] = "Seatbelt ON",
  ["seatbeltOff"] = "Seatbelt OFF"
}
